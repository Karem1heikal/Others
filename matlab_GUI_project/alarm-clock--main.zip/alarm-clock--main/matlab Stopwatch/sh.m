function varargout = sh(varargin)
% SH MATLAB code for sh.fig
%      SH, by itself, creates a new SH or raises the existing
%      singleton*.
%
%      H = SH returns the handle to a new SH or the handle to
%      the existing singleton*.
%
%      SH('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SH.M with the given input arguments.
%
%      SH('Property','Value',...) creates a new SH or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before sh_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to sh_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help sh

% Last Modified by GUIDE v2.5 31-Dec-2022 10:34:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @sh_OpeningFcn, ...
    'gui_OutputFcn',  @sh_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before sh is made visible.
function sh_OpeningFcn(hObject, eventdata, handles, varargin)
set(handles.edit1,'string','00');
set(handles.edit2,'string','00');
set(handles.edit3,'string','00');


% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to sh (see VARARGIN)

% Choose default command line output for sh
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes sh wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = sh_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)

% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in upmin.
function upmin_Callback(hObject, eventdata, handles)
min=str2double(get(handles.edit2,'string'));
min=min+1;
if(min==60)
    min=0;
end
if(min<=9)
    set(handles.edit2,'string',['0',num2str(min)]);
else
    set(handles.edit2,'string',num2str(min));
end
% hObject    handle to upmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in uphour.
function uphour_Callback(hObject, eventdata, handles)
hour=str2double(get(handles.edit3,'string'));
hour=hour+1;
if(hour==60)
    hour=0;
end
if(hour<=9)
    set(handles.edit3,'string',['0',num2str(hour)]);
else
    set(handles.edit3,'string',num2str(hour));
end
% hObject    handle to uphour (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in upsec.
function upsec_Callback(hObject, eventdata, handles)

sec=str2double(get(handles.edit1,'string'));
sec=sec+1;
if(sec==60)
    sec=0;
end
if(sec<=9)
    set(handles.edit1,'string',['0',num2str(sec)]);
else
    set(handles.edit1,'string',num2str(sec));
end
% hObject    handle to upsec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in downhour.
function downhour_Callback(hObject, eventdata, handles)
hour=str2double(get(handles.edit3,'string'));
hour=hour-1;
if(hour==-1)
    hour=59;
end
if(hour<=9)
    set(handles.edit3,'string',['0',num2str(hour)]);
else
    set(handles.edit3,'string',num2str(hour));
end
% hObject    handle to downhour (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in downmin.
function downmin_Callback(hObject, eventdata, handles)
min=str2double(get(handles.edit2,'string'));
min=min-1;
if(min==-1)
    min=59;
end
if(min<=9)
    set(handles.edit2,'string',['0',num2str(min)]);
else
    set(handles.edit2,'string',num2str(min));
end
% hObject    handle to downmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in downsec.
function downsec_Callback(hObject, eventdata, handles)

sec=str2double(get(handles.edit1,'string'));
sec=sec-1;
if(sec==-1)
    sec=59;
end
if(sec<=9)
    set(handles.edit1,'string',['0',num2str(sec)]);
else
    set(handles.edit1,'string',num2str(sec));
end
% hObject    handle to downsec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in start.
function start_Callback(hObject, eventdata, handles)
sec=str2double(get(handles.edit1,'string'));
min=str2double(get(handles.edit2,'string'));
hour=str2double(get(handles.edit3,'string'));
if((sec==0)&&(min==0)&&(hour==0))
else
    %------ disable buttons ----------
set(handles.upsec,'enable','off');
set(handles.downsec,'enable','off');
set(handles.upmin,'enable','off');
set(handles.downmin,'enable','off');
set(handles.uphour,'enable','off');
set(handles.downhour,'enable','off');
set(handles.clear1,'enable','off');
end
%loop  ---- secands------------
while(sec~=0)
    sec=sec-1;
    % --------- other button ------------
    % sop ==> stop
    sop=get(handles.Stop,'value');
    if (sop==1)
        sop=0;
        set(handles.Stop,'value',0);
        sec=0;
        min=0;
        hour=0;
        break;
    end
    % -------- display secands ----------
    if(sec<=9)
        set(handles.edit1,'string',['0',num2str(sec)]);
    else
        set(handles.edit1,'string',num2str(sec));
    end
    pause(1);
end
%loop  ---- minutes------------
while(min~=0)
    sec=60;
    min=min-1;
    % -------- display minute ---------
    if(min<=9)
        set(handles.edit2,'string',['0',num2str(min)]);
    else
        set(handles.edit2,'string',num2str(min));
    end
    while(sec~=0)
        sec=sec-1;
    % --------- other button ------------
    %sop ==> stop
    sop=get(handles.Stop,'value');  
    if (sop==1)
        sop=0;
        set(handles.Stop,'value',0);
        sec=0;
        min=0;
        hour=0;
        break;
    end
        % ------- display secands --------
        if(sec<=9)
        set(handles.edit1,'string',['0',num2str(sec)]);
        else
            set(handles.edit1,'string',num2str(sec));
        end
        pause(1);

    end
end
%loop  ---- hours------------
while(hour~=0)
    hour=hours-1;
    min=60;
    %--------- display hours -----------
    if(hour<=9)
        set(handles.edit3,'string',['0',num2str(hour)]);
    else
        set(handles.edit3,'string',num2str(hour));
    end
    while(min~=0)
    sec=60;
    min=min-1;
    %--------- display minutes -----------
    if(min<=9)
        set(handles.edit2,'string',['0',num2str(min)]);
    else
        set(handles.edit2,'string',num2str(min));
    end
    while(sec~=0)
    sec=sec-1;
    % --------- other button ------------
    % sop ==> stop
    sop=get(handles.Stop,'value');
    if (sop==1)
        sop=0;
        set(handles.Stop,'value',0);
        sec=0;
        min=0;
        hour=0;
        break;
    end
     %--------- display secands -----------
    if(sec<=9)
    set(handles.edit1,'string',['0',num2str(sec)]);
    else
        set(handles.edit1,'string',num2str(sec));
    end
    pause(1);
    end
    end
end
set(handles.uipanel3,'visible','on');
% (alarm)----Output audio

h=str2num(get(handles.text6,'string'));
switch h
    case 2
     clear sound
    [y,Fs]=audioread('tawakalto-tone.mp3');
    sound (y,Fs);
    case 3
    clear sound
    [y,Fs]=audioread('music_test2_alarm_clock_nice.mp3');
    sound (y,Fs);
    case 4
    clear sound
    [y,Fs]=audioread('music_test2_best_mrng_alarm.mp3');
    sound(y,Fs);
    case 5
    clear sound
    [y,Fs]=audioread('music_test2_holiday.mp3');
    sound(y,Fs);
    otherwise
    clear sound
    [y,Fs]=audioread('tawakalto-tone.mp3');
    sound (y,Fs);
end
pause(10);
clear sound
set(handles.uipanel3,'visible','off');
% enable buttons again
set(handles.upsec,'enable','on');
set(handles.downsec,'enable','on');
set(handles.upmin,'enable','on');
set(handles.downmin,'enable','on');
set(handles.uphour,'enable','on');
set(handles.downhour,'enable','on');
set(handles.clear1,'enable','on');


% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in Stop.
function Stop_Callback(hObject, eventdata, handles)
sec1=str2double(get(handles.edit1,'string'));
min1=str2double(get(handles.edit2,'string'));
hour1=str2double(get(handles.edit3,'string'));
set(handles.upsec,'enable','on');
set(handles.downsec,'enable','on');
set(handles.upmin,'enable','on');
set(handles.downmin,'enable','on');
set(handles.uphour,'enable','on');
set(handles.downhour,'enable','on');
set(handles.clear1,'enable','on');
if(sec1<=9)
    set(handles.edit1,'string',['0',num2str(sec1)]);
else
    set(handles.edit1,'string',num2str(sec1));
end
if(min1<=9)
    set(handles.edit2,'string',['0',num2str(min1)]);
else
    set(handles.edit2,'string',num2str(min1));
end
if(hour1<=9)
    set(handles.edit3,'string',['0',num2str(hour1)]);
else
    set(handles.edit3,'string',num2str(hour1));
end
clear sound
% hObject    handle to Stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in clear1.
function clear1_Callback(hObject, eventdata, handles)
sec=0;
min=0;
hour=0;
set(handles.upsec,'enable','on');
set(handles.downsec,'enable','on');
set(handles.upmin,'enable','on');
set(handles.downmin,'enable','on');
set(handles.uphour,'enable','on');
set(handles.downhour,'enable','on');
set(handles.clear1,'enable','on');
set(handles.edit1,'string',[num2str(sec),num2str(sec)]);
set(handles.edit2,'string',[num2str(min),num2str(min)]);
set(handles.edit3,'string',[num2str(hour),num2str(hour)]);
set(handles.clear1,'value',0);
clear sound
% hObject    handle to clear1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns miuplay contents as cell array
%        contents{get(hObject,'Value')} returns selected item from miuplay


% --- Executes during object creation, after setting all properties.
function miuplay_CreateFcn(hObject, eventdata, handles)

% hObject    handle to miuplay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object deletion, before destroying properties.
function figure1_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function upmin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to upmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function uphour_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uphour (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function upsec_CreateFcn(hObject, eventdata, handles)
% hObject    handle to upsec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function downhour_CreateFcn(hObject, eventdata, handles)
% hObject    handle to downhour (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function downmin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to downmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function downsec_CreateFcn(hObject, eventdata, handles)
% hObject    handle to downsec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function start_CreateFcn(hObject, eventdata, handles)
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function clear1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to clear1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




% --- Executes during object creation, after setting all properties.
function Stop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
clear sound
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function uipanel3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on selection change in pop.
function pop_Callback(hObject, eventdata, handles)
% (alarm)----Output audio
h=get(handles.pop,'value');
switch h
    case 2
     clear sound
    [y,Fs]=audioread('tawakalto-tone.mp3');
    sound (y,Fs);
    set(handles.text6,'string',h);
    case 3
    clear sound
    [y,Fs]=audioread('music_test2_alarm_clock_nice.mp3');
    sound (y,Fs);
    set(handles.text6,'string',h);
    case 4
    clear sound
    [y,Fs]=audioread('music_test2_best_mrng_alarm.mp3');
    sound(y,Fs);
    set(handles.text6,'string',h);
    case 5
    clear sound
    [y,Fs]=audioread('music_test2_holiday.mp3');
    sound(y,Fs);
    set(handles.text6,'string',h);
    case 6
        clear sound
end
% hObject    handle to pop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop


% --- Executes during object creation, after setting all properties.
function pop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function text6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
